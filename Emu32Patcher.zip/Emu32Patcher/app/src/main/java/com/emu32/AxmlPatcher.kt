package com.emu32

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Parchea in situ el AndroidManifest.xml binario (AXML) para subir targetSdkVersion.
 * Si el manifest no declara targetSdkVersion, Android usa minSdkVersion como target,
 * así que en ese caso se sube minSdkVersion (mismo efecto para la comprobación de instalación).
 * Cambia solo 4 bytes: no altera tamaños ni offsets.
 */
object AxmlPatcher {
    private const val RES_MIN_SDK = 0x0101020c
    private const val RES_TARGET_SDK = 0x01010270
    private const val TYPE_RESOURCE_MAP = 0x0180
    private const val TYPE_START_ELEMENT = 0x0102
    private const val TYPE_INT_DEC = 0x10

    class Result(val bytes: ByteArray, val field: String, val oldValue: Int, val newValue: Int)

    fun raiseSdk(src: ByteArray, wanted: Int): Result {
        val buf = ByteBuffer.wrap(src.copyOf()).order(ByteOrder.LITTLE_ENDIAN)
        require(buf.limit() > 8 && (buf.getShort(0).toInt() and 0xFFFF) == 0x0003) {
            "AndroidManifest.xml no es un XML binario válido"
        }
        var pos = buf.getShort(2).toInt() and 0xFFFF
        var resIds = IntArray(0)
        var minOff = -1
        var targetOff = -1

        while (pos + 8 <= buf.limit()) {
            val type = buf.getShort(pos).toInt() and 0xFFFF
            val size = buf.getInt(pos + 4)
            if (size <= 0) break
            if (type == TYPE_RESOURCE_MAP) {
                val n = (size - 8) / 4
                resIds = IntArray(n) { buf.getInt(pos + 8 + it * 4) }
            } else if (type == TYPE_START_ELEMENT) {
                val attrStart = buf.getShort(pos + 24).toInt() and 0xFFFF
                val attrSize = buf.getShort(pos + 26).toInt() and 0xFFFF
                val count = buf.getShort(pos + 28).toInt() and 0xFFFF
                for (i in 0 until count) {
                    val a = pos + 16 + attrStart + i * attrSize
                    val nameIdx = buf.getInt(a + 4)
                    when (resIds.getOrElse(nameIdx) { 0 }) {
                        RES_TARGET_SDK -> targetOff = a
                        RES_MIN_SDK -> minOff = a
                    }
                }
            }
            pos += size
        }

        val off = if (targetOff >= 0) targetOff else minOff
        val field = if (targetOff >= 0) "targetSdkVersion" else "minSdkVersion"
        require(off >= 0) { "El manifest no tiene <uses-sdk>; no se puede parchear" }
        require((buf.get(off + 15).toInt() and 0xFF) == TYPE_INT_DEC) { "Valor de $field no numérico" }

        val old = buf.getInt(off + 16)
        val new = maxOf(old, wanted)
        buf.putInt(off + 16, new)
        return Result(buf.array(), field, old, new)
    }
}
