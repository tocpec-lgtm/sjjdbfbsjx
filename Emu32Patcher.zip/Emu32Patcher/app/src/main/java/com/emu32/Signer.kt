package com.emu32

import android.content.Context
import com.android.apksig.ApkSigner
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

object Signer {
    fun sign(ctx: Context, input: File, output: File) {
        val (key, cert) = loadOrCreateKey(ctx)
        val cfg = ApkSigner.SignerConfig.Builder("emu32", key, listOf(cert)).build()
        if (output.exists()) output.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .build()
            .sign()
    }

    // La clave se genera una vez y se reutiliza: así los APK parcheados se pueden actualizar entre sí.
    private fun loadOrCreateKey(ctx: Context): Pair<PrivateKey, X509Certificate> {
        val kf = File(ctx.filesDir, "key.pk8")
        val cf = File(ctx.filesDir, "cert.der")
        if (!kf.exists() || !cf.exists()) {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=Emu32 Patcher")
            val now = System.currentTimeMillis()
            val day = 86_400_000L
            val holder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now - day), Date(now + 30L * 365 * day), name, kp.public
            ).build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
            val cert = JcaX509CertificateConverter().getCertificate(holder)
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(cert.encoded)
        }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(cf.readBytes().inputStream()) as X509Certificate
        return key to cert
    }
}
