package com.emu32

import android.content.Context
import android.os.Build
import java.io.File
import java.util.zip.ZipFile

object ApkAnalyzer {
    /** Android 14 bloquea instalar apps con target < 23 y Android 15 con target < 24. */
    const val MIN_TARGET = 24

    data class Report(
        val pkg: String,
        val label: String,
        val minSdk: Int,
        val targetSdk: Int,
        val abis: Set<String>,
        val needsPatch: Boolean,
        val runnable: Boolean,
        val verdict: String,
    ) {
        val canPatch get() = needsPatch && runnable

        fun text() = buildString {
            appendLine("$label")
            appendLine(pkg)
            appendLine()
            appendLine("minSdk: $minSdk   targetSdk: $targetSdk")
            appendLine("Librerías nativas: " + if (abis.isEmpty()) "ninguna (solo Java)" else abis.sorted().joinToString(", "))
            val dev = (if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) "64" else "") +
                (if (Build.SUPPORTED_32_BIT_ABIS.isNotEmpty()) (if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) " + 32" else "32") else "")
            appendLine("Tu teléfono ejecuta: $dev bits")
            appendLine()
            appendLine(verdict)
            appendLine()
            appendLine(
                when {
                    !runnable -> "No se puede parchear con este método."
                    needsPatch -> "Necesita parche: Android moderno rechaza targetSdk $targetSdk."
                    else -> "No necesita parche: instálalo normal."
                }
            )
        }
    }

    fun analyze(ctx: Context, apk: File): Report {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(apk.path, 0)
            ?: throw IllegalStateException("No pude leer el APK (¿es .xapk/split o está dañado?)")
        val ai = info.applicationInfo ?: throw IllegalStateException("APK sin datos de aplicación")
        ai.sourceDir = apk.path
        ai.publicSourceDir = apk.path
        val label = try { ai.loadLabel(pm).toString() } catch (e: Exception) { info.packageName }

        val abis = ZipFile(apk).use { z ->
            z.entries().toList().map { it.name }
                .filter { it.startsWith("lib/") && it.endsWith(".so") }
                .mapNotNull { it.split("/").getOrNull(1) }
                .toSet()
        }

        val dev64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
        val dev32 = Build.SUPPORTED_32_BIT_ABIS.isNotEmpty()
        val has64 = "arm64-v8a" in abis
        val has32 = "armeabi-v7a" in abis || "armeabi" in abis

        val (ok, verdict) = when {
            abis.isEmpty() -> true to "Solo Java, sin librerías nativas: el parche basta."
            has64 && dev64 -> true to "Trae librerías de 64 bits compatibles con tu teléfono."
            has32 && dev32 -> true to "Trae librerías de 32 bits y tu teléfono aún las ejecuta."
            has32 -> false to "Solo trae librerías de 32 bits y tu teléfono no las ejecuta. El parche no basta: hace falta emulación (etapa 2)."
            else -> false to "Solo trae librerías para otra arquitectura (x86/MIPS). No funcionará."
        }

        return Report(
            pkg = info.packageName,
            label = label,
            minSdk = ai.minSdkVersion,
            targetSdk = ai.targetSdkVersion,
            abis = abis,
            needsPatch = ai.targetSdkVersion < MIN_TARGET,
            runnable = ok,
            verdict = verdict,
        )
    }
}
