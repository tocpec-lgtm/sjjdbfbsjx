package com.emu32

import android.content.Context
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object Patcher {
    private fun isSignatureFile(n: String) =
        n.startsWith("META-INF/") &&
            (n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") ||
                n.endsWith(".DSA") || n.endsWith(".EC"))

    /** Devuelve el APK parcheado y firmado, más una nota para mostrar al usuario. */
    fun patch(ctx: Context, src: File, wantedTarget: Int): Pair<File, String> {
        val outDir = File(ctx.cacheDir, "out").apply { mkdirs() }
        val unsigned = File(outDir, "unsigned.apk")
        val signed = File(outDir, "patched.apk")
        var note = ""

        ZipFile(src).use { zip ->
            val manifest = zip.getEntry("AndroidManifest.xml")
                ?: throw IllegalStateException("El APK no tiene AndroidManifest.xml")
            val res = AxmlPatcher.raiseSdk(zip.getInputStream(manifest).readBytes(), wantedTarget)
            note = "Parche aplicado: ${res.field} ${res.oldValue} → ${res.newValue}"

            ZipOutputStream(unsigned.outputStream().buffered()).use { zos ->
                for (e in zip.entries()) {
                    if (isSignatureFile(e.name)) continue
                    val ne = ZipEntry(e.name)
                    when {
                        e.isDirectory -> { zos.putNextEntry(ne); zos.closeEntry() }
                        e.name == "AndroidManifest.xml" -> {
                            ne.method = ZipEntry.DEFLATED
                            zos.putNextEntry(ne); zos.write(res.bytes); zos.closeEntry()
                        }
                        e.method == ZipEntry.STORED -> {
                            ne.method = ZipEntry.STORED
                            ne.size = e.size; ne.compressedSize = e.size; ne.crc = e.crc
                            zos.putNextEntry(ne)
                            zip.getInputStream(e).use { it.copyTo(zos) }
                            zos.closeEntry()
                        }
                        else -> {
                            ne.method = ZipEntry.DEFLATED
                            zos.putNextEntry(ne)
                            zip.getInputStream(e).use { it.copyTo(zos) }
                            zos.closeEntry()
                        }
                    }
                }
            }
        }

        Signer.sign(ctx, unsigned, signed)
        unsigned.delete()
        return signed to note
    }
}
