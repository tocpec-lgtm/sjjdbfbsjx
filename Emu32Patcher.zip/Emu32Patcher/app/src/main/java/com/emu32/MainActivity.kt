package com.emu32

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var btnPatch: Button
    private var apk: File? = null
    private val pickCode = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply {
            text = "Emu32 Patcher"; textSize = 24f; setTypeface(null, Typeface.BOLD)
        }
        val btnPick = Button(this).apply {
            text = "Elegir APK"; setOnClickListener { pick() }
        }
        btnPatch = Button(this).apply {
            text = "Parchear e instalar"; isEnabled = false; setOnClickListener { patch() }
        }
        out = TextView(this).apply {
            text = "Elige un APK antiguo para analizarlo."; textSize = 15f; setPadding(0, pad, 0, pad)
        }
        root.addView(title); root.addView(btnPick); root.addView(btnPatch); root.addView(out)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        @Suppress("DEPRECATION") startActivityForResult(i, pickCode)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        out.text = "Analizando…"
        btnPatch.isEnabled = false
        Thread {
            try {
                val f = File(cacheDir, "in.apk")
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
                val r = ApkAnalyzer.analyze(this, f)
                apk = f
                runOnUiThread { out.text = r.text(); btnPatch.isEnabled = r.canPatch }
            } catch (e: Exception) {
                runOnUiThread { out.text = "Error: ${e.message}" }
            }
        }.start()
    }

    private fun patch() {
        val src = apk ?: return
        btnPatch.isEnabled = false
        out.text = "Parcheando y firmando…"
        Thread {
            try {
                val (f, note) = Patcher.patch(this, src, ApkAnalyzer.MIN_TARGET)
                runOnUiThread {
                    out.text = note + "\n\n" +
                        "Se firmó con una clave propia: desinstala antes la app original.\n" +
                        "Si el juego pide permisos (almacenamiento), concédelos a mano en Ajustes."
                    btnPatch.isEnabled = true
                    install(f)
                }
            } catch (e: Exception) {
                runOnUiThread { out.text = "Error: ${e.message}"; btnPatch.isEnabled = true }
            }
        }.start()
    }

    private fun install(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
