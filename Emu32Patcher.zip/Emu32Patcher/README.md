# Emu32 Patcher (etapa 1)

Analiza un APK antiguo y, si hace falta, sube su targetSdk y lo vuelve a firmar
para que Android moderno lo deje instalar.

Compilar: Android Studio (JDK 17) o GitHub Actions (.github/workflows/build.yml
genera el APK como artefacto).

Límites: no emula 32 bits (etapa 2, QEMU). Cambia la firma del APK.
